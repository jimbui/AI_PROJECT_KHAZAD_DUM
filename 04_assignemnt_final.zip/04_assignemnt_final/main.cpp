#include <time.h>
#include "Game.h" 

int main()
{
	BlackJack_Game the_room ;
	the_room.play_ball() ;
	return 0 ;
}